from flask import Flask, render_template, Response, jsonify
import cv2
import urllib.request
import numpy as np

app = Flask(__name__)

# Replace with your MJPEG stream URL
camera_url = 'http://77.103.172.17:8080/mjpg/video.mjpg?camera=2&timestamp=1726572356912'

def generate_frames():
    stream = urllib.request.urlopen(camera_url)
    bytes_stream = b''
    while True:
        bytes_stream += stream.read(1024)
        a = bytes_stream.find(b'\xff\xd8')
        b = bytes_stream.find(b'\xff\xd9')
        if a != -1 and b != -1:
            jpg = bytes_stream[a:b + 2]
            bytes_stream = bytes_stream[b + 2:]
            frame = cv2.imdecode(np.frombuffer(jpg, dtype=np.uint8), cv2.IMREAD_COLOR)
            
            # Parking spot detection logic
            parking_info = detect_parking_spots(frame)
            frame_with_info = annotate_frame(frame, parking_info)

            ret, buffer = cv2.imencode('.jpg', frame_with_info)
            frame = buffer.tobytes()
            
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

def detect_parking_spots(frame):
    # Example logic for detecting parking spots
    # Adjust the following logic to match your actual detection approach
    # For simplicity, let's assume each side of the road has 10 spots

    total_spots = 20  # Total spots on both sides combined
    occupied_spots = 7  # Example number of occupied spots
    empty_spots = total_spots - occupied_spots

    return {
        'total_spots': total_spots,
        'occupied_spots': occupied_spots,
        'empty_spots': empty_spots
    }

def annotate_frame(frame, parking_info):
    # Annotate frame with parking information
    cv2.putText(frame, f"Total Spots: {parking_info['total_spots']}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
    cv2.putText(frame, f"Occupied: {parking_info['occupied_spots']}", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    cv2.putText(frame, f"Empty: {parking_info['empty_spots']}", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    return frame

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/parking_status')
def parking_status():
    parking_info = detect_parking_spots(None)
    return jsonify(parking_info)

if __name__ == "__main__":
    app.run(debug=True)
